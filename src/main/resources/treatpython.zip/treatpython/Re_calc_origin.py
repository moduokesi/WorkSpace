import numpy as np
import meshio

"""
这个脚本可以重新计算3D模型的原点坐标，原始的分割结果，坐标轴的原点不在器官的中心点，此脚本旨在解决这个问题
"""

# 读取STL文件
stl_mesh = meshio.read('organ_1.stl')

# 获取顶点坐标
vertices = stl_mesh.points

# 计算中心点坐标
center = np.mean(vertices, axis=0)

translation_vector = -center

# 平移顶点坐标
translated_vertices = vertices + translation_vector

# 更新模型的顶点坐标
stl_mesh.points = translated_vertices

# 写入平移后的STL文件
meshio.write('output.stl', stl_mesh, file_format='stl')
