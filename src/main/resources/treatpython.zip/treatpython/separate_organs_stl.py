import SimpleITK as sitk
import vtk
from vtk.util import numpy_support
import numpy as np
import argparse
import os

"""
--image_path 需要器官分离的文件路径
--save_dir 保存路径
"""

parser = argparse.ArgumentParser()
parser.add_argument(
        '--image_path',
        type=str,
        required=True)

parser.add_argument(
        '--save_dir',
        dest='save_dir',
        help='The directory for saving the predict result.',
        type=str,
        default='./output')

args = parser.parse_args()

# 读取分割结果的标签图像
label_path = args.image_path
# label_path = "data/label/0b2be9e0-886b-4144-99f0-8bb4c6eaa848.nii"
label_image = sitk.ReadImage(label_path)

#获取save_dir路径
save_dir = args.save_dir
if not os.path.exists(save_dir):
    os.makedirs(save_dir)

# 将label图像转换为NumPy数组
label_array = sitk.GetArrayFromImage(label_image)

# 获取标签的唯一值
unique_labels = np.unique(label_array)

# 排除背景标签（通常为0）
background_label = 0
organ_labels = unique_labels[unique_labels != background_label]

for label in organ_labels:
    #类型转换
    label_float = float(label)

    # 创建器官的二进制掩膜图像
    organ_mask = sitk.BinaryThreshold(label_image, lowerThreshold=label_float, upperThreshold=label_float, insideValue=1, outsideValue=0)

    # 将 SimpleITK 图像转换为 NumPy 数组
    organ_array = sitk.GetArrayFromImage(organ_mask)

    # 创建 VTK 图像数据对象
    vtk_image = vtk.vtkImageData()
    vtk_image.SetOrigin(organ_mask.GetOrigin())
    vtk_image.SetSpacing(organ_mask.GetSpacing())
    vtk_image.SetDimensions(organ_mask.GetSize())

    # 将 NumPy 数组转换为 VTK 数据对象
    vtk_array = numpy_support.numpy_to_vtk(organ_array.ravel(), deep=True, array_type=vtk.VTK_FLOAT)
    vtk_image.GetPointData().SetScalars(vtk_array)

    # 使用 Marching Cubes 提取等值面
    marching_cubes_filter = vtk.vtkMarchingCubes()
    marching_cubes_filter.SetInputData(vtk_image)
    marching_cubes_filter.SetValue(0, 1)
    marching_cubes_filter.Update()

    surface = marching_cubes_filter.GetOutput()

    # 保存表面网格为 STL 文件
    stl_writer = vtk.vtkSTLWriter()
    stl_writer.SetInputData(surface)
    stl_filename = os.path.join(save_dir, f"organ_{label}.stl")
    stl_writer.SetFileName(stl_filename)
    stl_writer.Write()
