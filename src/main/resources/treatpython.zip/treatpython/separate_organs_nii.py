import SimpleITK as sitk
import numpy as np
import argparse
import os

parser = argparse.ArgumentParser()
parser.add_argument('--image_path', type=str, required=True)
parser.add_argument('--save_dir', dest='save_dir', help='The directory for saving the predict result.', type=str, default='./output')

args = parser.parse_args()

# 读取分割结果的标签图像
label_path = args.image_path
# label_path = "data/label/0b2be9e0-886b-4144-99f0-8bb4c6eaa848.nii"
label_image = sitk.ReadImage(label_path)

# 获取save_dir路径
save_dir = args.save_dir
if not os.path.exists(save_dir):
    os.makedirs(save_dir)

# 将label图像转换为NumPy数组
label_array = sitk.GetArrayFromImage(label_image)

# 获取标签的唯一值，获取结果文件中有多少个器官
unique_labels = np.unique(label_array)

# 排除背景标签（通常为0）
background_label = 0
organ_labels = unique_labels[unique_labels != background_label]

for label in organ_labels:
    # 类型转换
    label_float = float(label)

    # 创建器官的二进制掩膜图像
    organ_mask = sitk.BinaryThreshold(label_image, lowerThreshold=label_float, upperThreshold=label_float, insideValue=1, outsideValue=0)

    # 保存分割结果为NIfTI文件
    organ_filename = os.path.join(save_dir, f"organ_{label}.nii")
    sitk.WriteImage(organ_mask, organ_filename)

