import SimpleITK as sitk
import numpy as np
import cv2
import argparse

"""
nii文件多器官直径测量
输入nii文件
输出print 毫米
"""

parser = argparse.ArgumentParser()
parser.add_argument(
        '--image_path',
        type=str,
        required=True)

args = parser.parse_args()

def calculate_organ_diameters(nii_file_path):
    # 读取NIfTI图像文件
    image = sitk.ReadImage(nii_file_path)

    # 获取像素尺寸和体素体积
    spacing = image.GetSpacing()

    # 将标签图像转换为NumPy数组
    label_array = sitk.GetArrayFromImage(image)

    organ_labels = np.unique(label_array)
    organ_diameters = {}

    for organ_label in organ_labels:
        if organ_label == 0:
            continue

        # 提取器官区域
        organ_slices = np.uint8(label_array == organ_label)
        organ_slices = organ_slices.astype(np.uint8)

        max_diameter = 0
        for slice_index in range(organ_slices.shape[0]):
            organ_slice = organ_slices[slice_index]

            # 二值化器官区域
            _, binary_image = cv2.threshold(organ_slice, 0, 255, cv2.THRESH_BINARY)

            # 提取轮廓
            contours, _ = cv2.findContours(binary_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            # 计算直径
            for contour in contours:
                _, radius = cv2.minEnclosingCircle(contour)
                diameter = 2 * radius
                if diameter > max_diameter:
                    max_diameter = diameter

        # 转换为实际尺寸
        max_diameter *= spacing[0]  # 假设各维度像素尺寸相等，取x方向的像素尺寸

        organ_diameters[organ_label] = max_diameter

    return organ_diameters

# 示例用法
nii_file_path = args.image_path

organ_diameters = calculate_organ_diameters(nii_file_path)

for organ_label, diameter in organ_diameters.items():
    print(diameter)
