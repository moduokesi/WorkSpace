import SimpleITK as sitk
import vtk
from vtk.util import numpy_support
import argparse
import os

"""
命令行运行传入参数：
--image_path  需要转换成stl的nii或nii.gz文件路径
--save_dir 结果文件保存路径，默认为output
结果文件名与原文件名对应一致
"""


parser = argparse.ArgumentParser()
parser.add_argument(
        '--image_path',
        type=str,
        required=True)

parser.add_argument(
        '--save_dir',
        dest='save_dir',
        help='The directory for saving the predict result.',
        type=str,
        default='./output_stl')

args = parser.parse_args()

image_path = args.image_path
# image_path = "data/image/0b2be9e0-886b-4144-99f0-8bb4c6eaa848.nii"  # CT医学图像路径
image = sitk.ReadImage(image_path)

#读取保存路径
save_dir = args.save_dir
if not os.path.exists(save_dir):
    os.makedirs(save_dir)

# 将 SimpleITK 图像转换为 NumPy 数组
image_array = sitk.GetArrayFromImage(image)

# 创建 VTK 图像数据对象
vtk_image = vtk.vtkImageData()
vtk_image.SetOrigin(image.GetOrigin())
vtk_image.SetSpacing(image.GetSpacing())
vtk_image.SetDimensions(image.GetSize())

# 将 NumPy 数组转换为 VTK 数据对象
vtk_array = numpy_support.numpy_to_vtk(image_array.ravel(), deep=True, array_type=vtk.VTK_FLOAT)
vtk_image.GetPointData().SetScalars(vtk_array)

marching_cubes_filter = vtk.vtkMarchingCubes()
marching_cubes_filter.SetInputData(vtk_image)
marching_cubes_filter.SetValue(0, 1)
marching_cubes_filter.Update()

surface = marching_cubes_filter.GetOutput()

stl_writer = vtk.vtkSTLWriter()
stl_writer.SetInputData(surface)

#获取原文件名
filename = os.path.basename(image_path)

# 去除扩展名
if filename.endswith('.nii.gz'):
    filename = filename[:-7]
elif filename.endswith('.nii'):
    filename = filename[:-4]

stl_filename = os.path.join(save_dir, filename+'.stl')
stl_writer.SetFileName(stl_filename)
stl_writer.Write()
