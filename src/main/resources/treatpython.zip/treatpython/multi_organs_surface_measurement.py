import SimpleITK as sitk
import vtk
from vtk.util import numpy_support
import numpy as np
import argparse

"""
多器官表面积测量
输入为nii文件
输出为print输出，单位为平方厘米
"""

parser = argparse.ArgumentParser()
parser.add_argument(
    '--image_path',
    type=str,
    required=True,
    help='Path to the NIfTI image file.'
)
args = parser.parse_args()

def calculate_organ_surface_areas(nii_file_path):
    # 读取NIfTI图像文件
    image = sitk.ReadImage(nii_file_path)

    # 获取像素尺寸
    spacing = image.GetSpacing()

    # 获取标签图像的数组表示
    label_array = sitk.GetArrayFromImage(image)

    # 获取标签的唯一值，获取结果文件中有多少个器官
    unique_labels = np.unique(label_array)

    # 排除背景标签（通常为0）
    background_label = 0
    organ_labels = unique_labels[unique_labels != background_label]

    organ_surface_areas = {}
    for label in organ_labels:
        # 创建器官的二进制掩膜图像
        label_float = float(label)
        organ_mask = sitk.BinaryThreshold(image, lowerThreshold=label_float, upperThreshold=label_float, insideValue=1, outsideValue=0)

        # 将 SimpleITK 图像转换为 NumPy 数组
        organ_array = sitk.GetArrayFromImage(organ_mask)

        # 创建 VTK 图像数据对象
        vtk_image = vtk.vtkImageData()
        vtk_image.SetOrigin(organ_mask.GetOrigin())
        vtk_image.SetSpacing(organ_mask.GetSpacing())
        vtk_image.SetDimensions(organ_mask.GetSize())

        # 将 NumPy 数组转换为 VTK 数据对象
        vtk_array = numpy_support.numpy_to_vtk(organ_array.ravel(), deep=True, array_type=vtk.VTK_FLOAT)
        vtk_image.GetPointData().SetScalars(vtk_array)

        # 使用 Marching Cubes 提取器官的表面
        marching_cubes = vtk.vtkMarchingCubes()
        marching_cubes.SetInputData(vtk_image)
        marching_cubes.SetValue(0, 1)
        marching_cubes.Update()

        # 获取表面数据
        surface = marching_cubes.GetOutput()

        # 计算器官的表面积
        mass_properties = vtk.vtkMassProperties()
        mass_properties.SetInputData(surface)
        surface_area = mass_properties.GetSurfaceArea()

        # 存储器官表面积
        organ_surface_areas[label] = surface_area

    return organ_surface_areas

nii_file_path = args.image_path

organ_surface_areas = calculate_organ_surface_areas(nii_file_path)

conversion_factor = 0.01  # 1平方毫米 = 0.01平方厘米

# 输出结果
for label, surface_area in organ_surface_areas.items():
    surface_area_cm2 = surface_area * conversion_factor
    print(surface_area_cm2)

