import SimpleITK as sitk
import argparse

"""
输入为nii文件
输出为print输出，单位是立方厘米
"""

parser = argparse.ArgumentParser()
parser.add_argument(
        '--image_path',
        type=str,
        required=True,
        help='Path to the NIfTI file.')

args = parser.parse_args()

def calculate_organ_volume(nii_file_path):
    # 读取NIfTI图像文件
    image = sitk.ReadImage(nii_file_path)

    # 获取像素尺寸和体素体积
    spacing = image.GetSpacing()
    voxel_volume = spacing[0] * spacing[1] * spacing[2]

    # 计算器官的体积
    organ_volume = sitk.GetArrayFromImage(image).sum() * voxel_volume

    return organ_volume

# nii文件路径
nii_file_path = args.nii_file

# 体积换算 立方单位to立方厘米
conversion_factor = 0.001  # 1立方毫米 = 0.001立方厘米
volume_cubic_units = calculate_organ_volume(nii_file_path)
volume_cubic_cm = volume_cubic_units * conversion_factor

# 输出结果 立方厘米
print("Organ Volume (cubic cm):", volume_cubic_cm)
