import SimpleITK as sitk

image=sitk.ReadImage("D:\\Workspaces\\Project\\treattest\\treatdata\\1234567890\\infile\\0b2be9e0-886b-4144-99f0-8bb4c6eaa848.nii.gz")# 读取要转换格式的图像
cast_image = sitk.Cast(image, sitk.sitkUInt16)
sitk.WriteImage(cast_image, "data/dcm/output.dcm")