import numpy as np
import SimpleITK as sitk

# 读取label文件
label_path = 'data/label/0b2be9e0-886b-4144-99f0-8bb4c6eaa848.nii'
label_image = sitk.ReadImage(label_path)

# 将label图像转换为NumPy数组
label_array = sitk.GetArrayFromImage(label_image)

# 获取标签的唯一值
unique_labels = np.unique(label_array)

# 排除背景标签（通常为0）
background_label = 0
organ_labels = unique_labels[unique_labels != background_label]

# 计算器官标签数量
num_organs = len(organ_labels)

print(num_organs)
