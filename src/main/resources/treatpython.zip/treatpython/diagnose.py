import qianfan
import sys
sys.stdout.reconfigure(encoding='utf-8')

# 配置标准输入编码为UTF-8
sys.stdin = open(0, 'r', encoding='utf-8')

# 替换下列示例中参数，应用API Key替换your_ak，Secret Key替换your_sk
chat_comp = qianfan.ChatCompletion(ak="lV9lZ3ZrhaCuA4wLHozGg5je", sk="HMhpyXpQgwLfaCDDZvlkLB5ISC97mFGx")

# 下面是一个与用户对话的例子
msgs = qianfan.Messages()
while True:
    msgs.append(input())         # 增加用户输入
    resp = chat_comp.do(messages=msgs)
    print(resp.body)                  # 模型的输出
    msgs.append(resp)            # 追加模型输出
