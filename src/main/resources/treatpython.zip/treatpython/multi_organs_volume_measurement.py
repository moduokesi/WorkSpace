import SimpleITK as sitk
import numpy as np
import argparse

parser = argparse.ArgumentParser()
parser.add_argument(
        '--image_path',
        type=str,
        required=True)

args = parser.parse_args()

def calculate_organ_volumes(nii_file_path):
    # 读取NIfTI图像文件
    image = sitk.ReadImage(nii_file_path)

    # 获取像素尺寸和体素体积
    spacing = image.GetSpacing()
    voxel_volume = spacing[0] * spacing[1] * spacing[2]

    # 获取标签图像的数组表示
    label_array = sitk.GetArrayFromImage(image)

    # 获取标签的唯一值，获取结果文件中有多少个器官
    unique_labels = np.unique(label_array)

    # 排除背景标签（通常为0）
    background_label = 0
    organ_labels = unique_labels[unique_labels != background_label]

    organ_volumes = {}
    for label in organ_labels:
        # 创建器官的二进制掩膜图像
        label_float = float(label)
        organ_mask = sitk.BinaryThreshold(image, lowerThreshold=label_float, upperThreshold=label_float, insideValue=1, outsideValue=0)

        # 计算器官的体积
        organ_volume = sitk.GetArrayFromImage(organ_mask).sum() * voxel_volume

        # 存储器官体积
        organ_volumes[label] = organ_volume

    return organ_volumes

# 示例用法
nii_file_path = args.image_path

# 体积换算 立方单位to立方厘米
conversion_factor = 0.001  # 1立方毫米 = 0.001立方厘米
organ_volumes_cubic_units = calculate_organ_volumes(nii_file_path)
organ_volumes_cubic_cm = {label: volume * conversion_factor for label, volume in organ_volumes_cubic_units.items()}

# 输出结果 立方厘米
for label, volume in organ_volumes_cubic_cm.items():
    print(volume)
